/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptions;

/**
 *
 * @author leoli
 */
public class OutOfBoundsException extends Exception{
    public OutOfBoundsException(String s){
        super(s);
    }
    public OutOfBoundsException(){}
}
